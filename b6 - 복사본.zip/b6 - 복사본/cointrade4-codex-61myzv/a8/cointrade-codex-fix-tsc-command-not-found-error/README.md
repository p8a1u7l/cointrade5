# 코인트레이드 제니스
이 저장소는 **Zenith Trader Suite**의 전체 구성을 제공합니다. 이 샘플은 바이낸스 선물 자동매매, GPT-5 Pro 기반 시그널 생성, 그리고 Webull 스타일의 제어 대시보드를 통합한 완성형 예시입니다.

- `zenith/backend` – 실행을 관리하고 자체 인메모리 테레메트리를 노출하는 경량 Node.js 오케스트레이터
- `zenith/frontend` – 리스크 제어와 모니터링을 위한 React 대시보드
- `zenith/supabase` – (보관용) 과거 Supabase 아키텍처 자산

시작 방법과 세부 설정은 각 디렉터리의 README에서 확인할 수 있습니다. 전체적인 개요는 `zenith/README.md`부터 살펴보세요.
